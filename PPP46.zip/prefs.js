pref("extensions.base-plug.intensity", 100);
pref("extensions.clipboard-pdf-importer.enabled", true);
pref("extensions.clipboard-pdf-importer.mode", "force");
