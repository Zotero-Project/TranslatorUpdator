# TranslatorUpdator
base zotero 7 plugin
